-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Gazdă: 127.0.0.1
-- Timp de generare: mai 21, 2022 la 01:15 PM
-- Versiune server: 10.4.24-MariaDB
-- Versiune PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Bază de date: `productdb`
--

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `producttb`
--

CREATE TABLE `producttb` (
  `id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` float DEFAULT NULL,
  `product_image` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Eliminarea datelor din tabel `producttb`
--

INSERT INTO `producttb` (`id`, `product_name`, `product_price`, `product_image`) VALUES
(10, 'Ceai verde cu lamaie si ghimbir', 25, './images/cv1.jpg'),
(11, 'Ceai verde cu ginseng si ghimbir', 22, './images/cv2.jpg'),
(12, 'Ceai verde cu iasomie', 24, './images/cv3.jpg'),
(13, 'Ceai verde cu scortisoara si portocale', 21, './images/cv4.jpg'),
(14, 'Ceai verde Sakura Cherry', 20, './images/cv6.jpg'),
(15, 'Ceai negru cu trandafir si portocala', 18, './images/cn1.jpg'),
(16, 'Ceai negru si caramel', 30, './images/cn_1.png'),
(17, 'Ceai negru cu ciocolata', 20, './images/cn2.jpg'),
(18, 'Ceai negru cu galbenele', 32, './images/cn4.png'),
(19, ' Ceai Matcha Taishan', 45, ' ./images/cm1.jpg'),
(20, 'Ceai negru Tanzania', 30, ' ./images/cn5.jpg'),
(21, 'Ceai Rooibos Banana Muffin', 15, './images/cr1.jpg'),
(22, 'Ceai rooibos cu migdale prajite', 18, './images/cr2.jpg'),
(23, 'Ceai Rooibos Mar Copt', 30, './images/cr3.jpg'),
(24, 'Ceai Negru Pu-Erh Perle Cacao', 20, './images/ce1.jpg'),
(25, 'Ceai Pu Erh de Craciun', 30, ' ./images/ce2.jpg'),
(26, 'Ceai Ayurvedic Relax', 20, './images/ca2.jpg'),
(27, 'Ceai Lapacho Original', 15, './images/cl1.jpg'),
(28, 'Ceai de fructe Cherry-Banana', 22, './images/cf1.jpg'),
(29, 'Ceai de fructe Miami Ice Tea', 22, './images/cf2.jpg'),
(30, 'Ceai de fructe Orange Dream', 20, './images/cf3.jpg'),
(31, 'Ceai fructe Palais Royal', 15, './images/cf4.jpg'),
(32, 'Ceai de menta marocana', 25, './images/cm2.jpg'),
(33, 'Ceai Infuzie de Seara', 30, './images/ci1.jpg'),
(34, 'Infuzie Ceaiul Copiilor', 20, './images/ci2.jpg'),
(35, 'Infuzie plante Melissa Lemon', 25, './images/ci3.jpg'),
(36, 'Ceai rooibos cu ghimbir si lamaie', 22, './images/cg1.jpg'),
(37, 'Ceai Negru Choc Chai', 24, './images/cm3.jpg'),
(38, 'Ceai Aloe Vera Elixirul Tineretii', 22, './images/c1.jpg'),
(39, 'Ceai flori de Hibiscus', 15, './images/c2.jpg'),
(40, 'Ceai Muntele Grecesc - Sideritis', 25, './images/c3.jpg'),
(41, 'Ceai Yerba Mate Brazilian', 15, './images/c4.jpg'),
(42, 'Infuzie Moringa Matcha Mango', 20, './images/c5.jpg'),
(43, 'Ceai de fructe Naughty John', 23, './images/c6.jpg'),
(44, 'Ceai Blooming Tea Mary Blue', 5, './images/c7.jpg'),
(45, 'Ceai Gunpowder Temple of Heaven', 17, './images/c8.jpg'),
(46, 'Ceai verde Sencha Ginseng Rosu', 45, './images/c9.jpg'),
(47, 'Ceai Matcha Beginners 30g', 100, './images/c10.jpg'),
(48, 'Set cadou Ceai Matcha Ceremonial', 400, './images/c11.jpg'),
(49, 'Ceai Matcha Japan Deluxe BIO 30g', 190, './images/c12.jpg'),
(50, 'Ceai rooibos Cafe Rustic', 20, './images/c13.jpg'),
(51, 'Ceai rooibos cu cacao', 19, './images/c14.jpg'),
(52, 'Ceai Rooibos Hello Sunshine', 23, './images/c15.jpg'),
(53, 'Ceai Rooibos Rosu African', 20, './images/c16.jpg'),
(54, 'Ceai Rooibos Smochine si Kiwi', 17, './images/c17.jpg'),
(55, 'Ceai Ayurvedic Pitta', 27, './images/c18.jpg'),
(56, 'Ceai Ayurvedic Vata', 30, './images/c19.jpg'),
(57, 'Ceai Ayurveda Pure', 22, './images/c20.jpg'),
(58, 'Ceai Blooming Tea Black Jasmine', 10, './images/c21.jpg'),
(59, 'Ceai Blooming Tea Bill', 9, './images/c22.jpg'),
(60, 'Set cadou ceaiuri rare', 350, './images/c23.jpg'),
(61, 'Ceai alb White Monkey China', 50, './images/c24.jpg'),
(62, 'Ceai alb Gift of the Gods', 35, './images/c25.jpg');

--
-- Indexuri pentru tabele eliminate
--

--
-- Indexuri pentru tabele `producttb`
--
ALTER TABLE `producttb`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pentru tabele eliminate
--

--
-- AUTO_INCREMENT pentru tabele `producttb`
--
ALTER TABLE `producttb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
